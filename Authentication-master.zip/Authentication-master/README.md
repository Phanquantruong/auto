# Authentication
C# PHP and MySQL Login, Registration and Token System
